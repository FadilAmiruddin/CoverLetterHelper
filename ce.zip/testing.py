from openai import OpenAI

client = OpenAI(
    api_key="YOUR_API_KEY",
    base_url="a7fc6ed1871248dca13216ee38b04e74"
)

response = client.chat.completions.create(
    model="mistralai/Mistral-7B-Instruct-v0.2",
    messages=[
        {
            "role": "system",
            "content": "You are an AI assistant who knows everything.",
        },
        {
            "role": "user",
            "content": "Tell me, why is the sky blue?"
        },
    ],
)

message = response.choices[0].message.content
print(f"Assistant: {message}")